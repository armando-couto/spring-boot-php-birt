import java.math.BigDecimal;

public class NumberTest {

	public Integer getInteger() {
		return new Integer(-20);
	}
	
	public int getPrimitiveInt() {
		return -20;
	}

	public Float getFloat() {
		return new Float(-20);
	}

	public float getPrimitiveFloat() {
			return -20;
	}
	
	public BigDecimal getBigDecimal() {
		return new BigDecimal(-20);
	}

	public Double getDouble() {
		return new Double(-20);
	}

	public double getPrimitiveDouble() {
		return -20;
	}

}