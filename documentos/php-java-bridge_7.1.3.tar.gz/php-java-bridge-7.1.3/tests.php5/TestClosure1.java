public interface TestClosure1 {
    public Object g();
}
