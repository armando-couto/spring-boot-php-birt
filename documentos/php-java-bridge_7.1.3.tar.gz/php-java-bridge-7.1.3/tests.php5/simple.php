<?php
  // Remove all entries from the php.ini and call this twice, with and
  // w/o java.so
include_once("java/Java.inc");
echo java_server_name();
?>
